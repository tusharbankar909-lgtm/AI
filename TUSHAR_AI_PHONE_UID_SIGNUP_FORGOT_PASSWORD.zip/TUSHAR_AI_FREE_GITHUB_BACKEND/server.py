import os, re, secrets, shutil, sqlite3, uuid, hashlib
from datetime import date
from pathlib import Path
import requests
from fastapi import FastAPI, UploadFile, File, Request, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / 'uploads'; UPLOADS.mkdir(exist_ok=True)
DB_PATH = BASE / 'tushar_ai.db'
app = FastAPI(title='TUSHAR AI')
app.add_middleware(SessionMiddleware, secret_key=os.getenv('TUSHAR_SESSION_SECRET','CHANGE_THIS_SESSION_SECRET_BEFORE_DEPLOY'), same_site='lax', https_only=os.getenv('TUSHAR_COOKIE_SECURE','0')=='1', max_age=60*60*24*30)
app.mount('/static', StaticFiles(directory=BASE/'static'), name='static')
OLLAMA_URL=os.getenv('OLLAMA_URL','http://127.0.0.1:11434'); DEFAULT_MODEL=os.getenv('OLLAMA_MODEL','qwen2.5:3b')
TWILIO_ACCOUNT_SID=os.getenv('TWILIO_ACCOUNT_SID','').strip(); TWILIO_AUTH_TOKEN=os.getenv('TWILIO_AUTH_TOKEN','').strip(); TWILIO_VERIFY_SERVICE_SID=os.getenv('TWILIO_VERIFY_SERVICE_SID','').strip()


def db():
    con=sqlite3.connect(DB_PATH); con.row_factory=sqlite3.Row; return con

def init_db():
    con=db(); con.execute('''CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT UNIQUE NOT NULL, phone TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL, age INTEGER NOT NULL, dob TEXT NOT NULL, password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_login TEXT)''')
    # Migrate an older TUSHAR AI auth database if present.
    cols={r['name'] for r in con.execute('PRAGMA table_info(users)').fetchall()}
    wanted={'phone':'TEXT','name':'TEXT','age':'INTEGER','dob':'TEXT'}
    for c,t in wanted.items():
        if c not in cols:
            con.execute(f'ALTER TABLE users ADD COLUMN {c} {t}')
    con.commit(); con.close()
init_db()

def hash_password(password, salt=None):
    salt=salt or secrets.token_bytes(16); digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,210000)
    return f'pbkdf2_sha256$210000${salt.hex()}${digest.hex()}'

def verify_password(password, encoded):
    try:
        scheme, rounds, salt_hex, digest_hex=encoded.split('$');
        if scheme!='pbkdf2_sha256': return False
        actual=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt_hex),int(rounds))
        return secrets.compare_digest(actual,bytes.fromhex(digest_hex))
    except Exception: return False

def valid_password(p): return 8 <= len(p) <= 128

def normalize_phone(p):
    p=re.sub(r'[\s()-]','',str(p or ''))
    if p.startswith('00'): p='+'+p[2:]
    return p

def valid_phone(p): return bool(re.fullmatch(r'\+[1-9]\d{7,14}',p))

def new_uid(con):
    while True:
        uid='TUS-'+secrets.token_hex(4).upper()
        if con.execute('SELECT 1 FROM users WHERE uid=?',(uid,)).fetchone() is None: return uid

def current_user(request):
    uid=request.session.get('uid')
    if not uid: return None
    con=db(); row=con.execute('SELECT id,uid,phone,name,age,dob,created_at FROM users WHERE uid=?',(uid,)).fetchone(); con.close(); return row

def require_user(request):
    u=current_user(request)
    if u is None: raise HTTPException(status_code=401,detail='Login required')
    return u

def send_otp(phone):
    if not (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_VERIFY_SERVICE_SID):
        return False, 'Phone OTP is not configured. Add TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_VERIFY_SERVICE_SID.'
    try:
        r=requests.post(f'https://verify.twilio.com/v2/Services/{TWILIO_VERIFY_SERVICE_SID}/Verifications',auth=(TWILIO_ACCOUNT_SID,TWILIO_AUTH_TOKEN),data={'To':phone,'Channel':'sms'},timeout=15)
        if not r.ok: return False, 'SMS provider rejected the request.'
        return True, None
    except Exception: return False, 'Could not contact the SMS provider.'

def check_otp(phone,otp):
    if not (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_VERIFY_SERVICE_SID): return False
    try:
        r=requests.post(f'https://verify.twilio.com/v2/Services/{TWILIO_VERIFY_SERVICE_SID}/VerificationCheck',auth=(TWILIO_ACCOUNT_SID,TWILIO_AUTH_TOKEN),data={'To':phone,'Code':otp},timeout=15)
        return r.ok and r.json().get('status')=='approved'
    except Exception: return False

@app.get('/')
def home(): return FileResponse(BASE/'static/index.html')
@app.get('/api/health')
def health():
    try: ok=requests.get(f'{OLLAMA_URL}/api/tags',timeout=2).ok
    except Exception: ok=False
    return {'ok':True,'ollama':ok,'model':DEFAULT_MODEL}
@app.get('/api/auth/me')
def auth_me(request:Request):
    u=current_user(request); return {'authenticated':bool(u),'user':dict(u) if u else None}

@app.post('/api/auth/send-otp')
async def auth_send_otp(payload:dict,request:Request):
    phone=normalize_phone(payload.get('phone'))
    if not valid_phone(phone): return {'error':'Enter a valid phone number with country code, e.g. +919876543210.'}
    con=db(); exists=con.execute('SELECT 1 FROM users WHERE phone=?',(phone,)).fetchone(); con.close()
    if exists: return {'error':'This phone number is already registered. Use UID login.'}
    ok,msg=send_otp(phone)
    if not ok: return {'error':msg}
    request.session['pending_phone']=phone
    return {'ok':True,'message':'OTP sent.'}

@app.post('/api/auth/verify-otp')
async def auth_verify_otp(payload:dict,request:Request):
    phone=normalize_phone(payload.get('phone')); otp=str(payload.get('otp','')).strip()
    if request.session.get('pending_phone')!=phone: return {'error':'Request a new OTP first.'}
    if not re.fullmatch(r'\d{4,8}',otp) or not check_otp(phone,otp): return {'error':'Invalid or expired OTP.'}
    request.session['phone_verified']=True
    return {'ok':True}

@app.post('/api/auth/signup')
async def auth_signup(payload:dict,request:Request):
    phone=normalize_phone(payload.get('phone')); name=str(payload.get('name','')).strip(); dob=str(payload.get('dob','')).strip(); password=str(payload.get('password','')); password2=str(payload.get('password2',''))
    try: age=int(payload.get('age'))
    except Exception: age=0
    if request.session.get('pending_phone')!=phone or not request.session.get('phone_verified'): return {'error':'Verify your phone with OTP first.'}
    if not name or len(name)>80: return {'error':'Enter your name.'}
    if age<13 or age>120: return {'error':'Enter a valid age.'}
    try:
        dob_date=date.fromisoformat(dob)
        if dob_date>date.today(): raise ValueError()
    except Exception: return {'error':'Enter a valid date of birth.'}
    if not valid_password(password): return {'error':'Password must be 8 to 128 characters.'}
    if password!=password2: return {'error':'Passwords do not match.'}
    con=db()
    if con.execute('SELECT 1 FROM users WHERE phone=?',(phone,)).fetchone(): con.close(); return {'error':'Phone number already registered.'}
    requested_uid=str(payload.get('uid','')).strip().upper()
    if not re.fullmatch(r'TUS-[A-Z0-9]{4,12}', requested_uid):
        con.close(); return {'error':'Choose a UID using TUS- plus 4-12 letters/numbers, e.g. TUS-ROHAN99.'}
    if con.execute('SELECT 1 FROM users WHERE uid=?',(requested_uid,)).fetchone():
        con.close(); return {'error':'That UID is already taken. Choose another one.'}
    uid=requested_uid
    con.execute('INSERT INTO users(uid,phone,name,age,dob,password_hash) VALUES(?,?,?,?,?,?)',(uid,phone,name,age,dob,hash_password(password)))
    con.commit(); con.close(); request.session.clear(); request.session['uid']=uid
    return {'ok':True,'user':{'uid':uid,'phone':phone,'name':name,'age':age,'dob':dob}}

@app.post('/api/auth/login')
async def auth_login(payload:dict,request:Request):
    uid=str(payload.get('uid','')).strip().upper(); password=str(payload.get('password',''))
    if not re.fullmatch(r'TUS-[A-Z0-9]{4,12}',uid): return {'error':'Enter a valid TUSHAR AI UID.'}
    attempts=int(request.session.get('login_failures',0))
    con=db(); row=con.execute('SELECT id,uid,phone,name,age,dob,created_at,password_hash FROM users WHERE uid=?',(uid,)).fetchone()
    if not row or not row['password_hash'] or not verify_password(password,row['password_hash']):
        con.close(); attempts += 1; request.session['login_failures']=attempts
        return {'error':'Invalid UID or password.','failed_attempts':attempts,'show_forgot':attempts>=4}
    con.execute('UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?',(row['id'],)); con.commit(); con.close(); request.session.clear(); request.session['uid']=uid
    return {'ok':True,'user':{k:row[k] for k in ('uid','phone','name','age','dob','created_at')}}

@app.post('/api/auth/forgot-send-otp')
async def forgot_send_otp(payload:dict,request:Request):
    uid=str(payload.get('uid','')).strip().upper()
    if int(request.session.get('login_failures',0)) < 4: return {'error':'Forgot Password becomes available after 4 failed login attempts.'}
    con=db(); row=con.execute('SELECT phone FROM users WHERE uid=?',(uid,)).fetchone(); con.close()
    if not row: return {'error':'UID not found.'}
    ok,msg=send_otp(row['phone'])
    if not ok: return {'error':msg}
    request.session['forgot_uid']=uid
    return {'ok':True,'message':'OTP sent to the registered phone number.'}

@app.post('/api/auth/forgot-reset')
async def forgot_reset(payload:dict,request:Request):
    uid=str(payload.get('uid','')).strip().upper(); otp=str(payload.get('otp','')).strip(); new_password=str(payload.get('password',''))
    if int(request.session.get('login_failures',0)) < 4: return {'error':'Forgot Password is not enabled yet.'}
    if request.session.get('forgot_uid') != uid: return {'error':'Request a password-reset OTP first.'}
    con=db(); row=con.execute('SELECT phone FROM users WHERE uid=?',(uid,)).fetchone()
    if not row: con.close(); return {'error':'UID not found.'}
    if not check_otp(row['phone'],otp): con.close(); return {'error':'Invalid or expired OTP.'}
    if not valid_password(new_password): con.close(); return {'error':'Password must be 8 to 128 characters.'}
    con.execute('UPDATE users SET password_hash=? WHERE uid=?',(hash_password(new_password),uid)); con.commit(); con.close()
    request.session['login_failures']=0; request.session.pop('forgot_uid',None)
    return {'ok':True,'message':'Password changed. You can now login with your UID and new password.'}

@app.post('/api/auth/logout')
def logout(request:Request): request.session.clear(); return {'ok':True}

@app.post('/api/chat')
async def chat(payload:dict,request:Request):
    require_user(request); msg=payload.get('message',''); model=payload.get('model') or DEFAULT_MODEL
    if not msg: return {'error':'Message required'}
    try:
        r=requests.post(f'{OLLAMA_URL}/api/chat',json={'model':model,'messages':[{'role':'user','content':msg}],'stream':False},timeout=120); r.raise_for_status(); return {'reply':r.json().get('message',{}).get('content',''),'model':model}
    except Exception as e: return {'reply':'Local AI is not running. Start Ollama and pull the model.','error':str(e)}

@app.post('/api/upload')
async def upload(request:Request,file:UploadFile=File(...)):
    require_user(request); safe=Path(file.filename or 'file').name; dest=UPLOADS/f'{uuid.uuid4().hex}_{safe}'
    with dest.open('wb') as f: shutil.copyfileobj(file.file,f)
    return {'name':safe,'path':dest.name,'size':dest.stat().st_size}

@app.post('/api/storyboard')
async def storyboard(payload:dict,request:Request):
    require_user(request); story=payload.get('story','').strip(); model=payload.get('model') or DEFAULT_MODEL
    if not story: return {'error':'Story required'}
    prompt=f'''Create a video storyboard from this story. Return JSON only with a scenes array. Each scene must contain scene, duration_seconds, visual_prompt, narration. Story:\n{story}'''
    try:
        r=requests.post(f'{OLLAMA_URL}/api/chat',json={'model':model,'messages':[{'role':'user','content':prompt}],'stream':False},timeout=120); r.raise_for_status(); return {'storyboard':r.json().get('message',{}).get('content','')}
    except Exception as e: return {'storyboard':'AI storyboard unavailable. Start Ollama first.','error':str(e)}

@app.get('/api/tools')
def tools(request:Request):
    require_user(request); return {'tools':['AI Chat','Female Voice','Image Generator','HD/4K Upscaler','Background Remover','OCR','PDF Chat','Translator','Speech-to-Text','Text-to-Speech','Study Tutor','Notes','CSV/Excel Analyzer','Website Builder','Code Helper','Debugger','Project ZIP Builder','Web Research','AI Agent','Story to Video']}
