# TUSHAR AI — Phone OTP + UID Authentication

## Signup flow
1. User enters phone number.
2. Backend sends an SMS OTP using Twilio Verify.
3. User verifies OTP.
4. TUSHAR AI asks: Your Name, Age, Date of Birth, Password and confirmation.
5. Backend creates a unique UID such as `TUS-8F42A1BC`.
6. The user is logged in automatically.
7. Later, the user can log in on any device with UID + password.

## Required environment variables for real SMS
Set these on the backend/server:
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_VERIFY_SERVICE_SID`
- `TUSHAR_SESSION_SECRET` (use a long random secret in production)
- `TUSHAR_COOKIE_SECURE=1` when running behind HTTPS
- Optional Ollama: `OLLAMA_URL`, `OLLAMA_MODEL`

Never put the Twilio Auth Token or a user's password in frontend code or chat.

## Run
```bash
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8000
```
Then open `http://127.0.0.1:8000`.

## Important
Real phone OTP requires an SMS verification provider. This build uses Twilio Verify; it does not fake OTPs in production.
